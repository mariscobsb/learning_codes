class Ad < ApplicationRecord
  belongs_to :user
end
