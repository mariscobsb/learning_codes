class ApplicationMailer < ActionMailer::Base
  default from: 'no-reply@dioclassificados.com'
  layout 'mailer'
end
