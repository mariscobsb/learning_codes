import * as extensions from './matchers'

expect.extend(extensions)
