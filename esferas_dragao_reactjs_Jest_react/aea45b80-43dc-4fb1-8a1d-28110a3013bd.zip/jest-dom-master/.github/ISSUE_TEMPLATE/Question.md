---
name: ❓ Support Question
about: 🛑 If you have a question 💬, please check out our support channels!
---

------------ 👆 Click "Preview"!

Issues on GitHub are intended to be related to problems with the library itself
and feature requests so we recommend not using this medium to ask them here 😁.

---

## ❓ Support Forums

- React Spectrum https://spectrum.chat/react-testing-library
- Reactiflux on Discord https://www.reactiflux.com
- Stack Overflow https://stackoverflow.com/questions/tagged/jest-dom

**ISSUES WHICH ARE QUESTIONS WILL BE CLOSED**
